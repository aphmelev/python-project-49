#!/usr/bin/env python3
import brain_games.games.brain_calc as brain_calc
import brain_games.scripts.brain_hello as hello


def main():
    brain_calc.start(hello.hello())
